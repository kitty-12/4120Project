------------------------------------------------------
TINY FANTASY ICONS
------------------------------------------------------

Thanks for purchasing Tiny Fantasy Icons from the Unity Asset Store.
Don't forget to leave me a review! :) Hopefully a nice one...

If you need 3d models for this icon collection you can grab it here:

https://assetstore.unity.com/packages/3d/environments/fantasy/tiny-fantasy-loot-53326


Also, if you need a dungeon for this treasures, this has the same visual style:
	
Tiny Dungeon
https://assetstore.unity.com/packages/3d/environments/dungeons/tiny-dungeons-48170

Tiny Lair
https://assetstore.unity.com/packages/3d/environments/dungeons/tiny-lair-88355



If you have any questions or feedback, you can contact me at :

	* E-mail: vespawarrior3d@gmail.com
	* Twitter: @Vespawarrior


------------------------------------------------------
Release notes:
------------------------------------------------------


V 1.0
	- Initial release

